# Ruby on Rails Tutorial: sample app

This is the sample application for the [Ruby on Rails Tutorial](http://railstutorial.org/) by [Michael Hartl](http://michaelhartl.com/).

**NOTE**: This application is out of date. For the most up-to-date version of the Rails Tutorial sample application, see the [Rails Tutorial Help page](http://railstutorial.org/help).
